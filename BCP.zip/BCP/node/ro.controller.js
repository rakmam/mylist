//const romodel = require('../models/ro.model');
console.log("hiii");
// get all RO list
exports.getAllRoList = (req,res) => {
    console.log("All Ro list");
    /*romodel.getRoList((err,roList)=> {
        console.log("here");
        if(err){
            res.send(err);
        }else{
            res.send(roList);
        }

    })*/
}