const express = require('express');
const app = express();
const cors = require('cors');

const router = require('./router');

const port = process.env.PORT || 3000 ;
app.use(cors({
    origin: 'http://localhost:4200'
}));

app.use('/api',cors(), router);
app.get('/', cors(), (req,res) => {
    res.json({"msg":"Welcome Node API"})
});

app.listen(port,()=>{console.log("Listening to the server at http://localhost:3000")});