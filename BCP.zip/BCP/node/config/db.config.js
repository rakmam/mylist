const mysql = require('mysql');

// mysql connection
const dbConn = mysql.createConnection({
    host : 'localhost',
    user : 'root',
    password : '',
    database : 'bcp_db'
});
dbConn.connect((error) => {
    if(error) {
    throw error
    }else{
    console.log('Database connected Succesfully');
    }
});

module.exports = dbConn;