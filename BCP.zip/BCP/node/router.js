const express = require('express');
const router = express.Router();
const romodel = require('./ro.model');

router.get('/data', (req, res) => {
    romodel.getRopHList((err,roList)=> {
        if(err){
            res.send(err);
        }else{
            res.send(roList);
        }

    })
});

module.exports=router;