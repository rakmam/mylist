var dbConn = require('./config/db.config');
var ro = (ro) => {
    this.inlet_ph = ro.inlet_ph;
    this.applied_date = ro.applied_date;
} 

ro.getRopHList = (result) => {
    dbConn.query("select inlet_ph,applied_date from rotbl" , (err,res) => {
        if(err){
            console.log("Error in feteching");
            result(null,err);
        }else{
            console.log(res);
            result(null,res);
        }
    })
}


module.exports = ro;