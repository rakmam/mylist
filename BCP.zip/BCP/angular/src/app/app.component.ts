import { Component, VERSION ,OnInit } from '@angular/core';
import * as Highcharts from 'highcharts';
import { AppServiceService } from './app-service.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.scss' ]
})
export class AppComponent  implements OnInit{
  stringJson: any;
  stringObject: any;
 public options: any = {
    chart: {
      type: 'spline',
      height: 700
    },
    title: {
      text: ''
    },
    credits: {
      enabled: false
    },

    xAxis: {
      categories:["2021-08-01", "2021-08-02", "2021-08-03", "2021-08-04", "2021-08-05", "2021-08-06", "2021-08-07", "2021-08-08", "2021-08-09", "2021-08-10", "2021-08-11", "2021-08-12"]

    },
    series: [
         {
            name: 'Outlet pH',
            data: [6.0, 6.9, 6.5, 7.5, 7.2, 7.5, 8.2,8.5, 8.3, 9.3, 9.9, 10]
         }
         
      ]
  }


  constructor(private service : AppServiceService) { }

  ngOnInit(){
    this.getDataFromAPI();
    Highcharts.chart('container', this.options);
  }
  getDataFromAPI(){
    let chartData=[];
    this.service.getData().subscribe((response) => {
    this.stringJson=JSON.stringify(response);
    this.stringObject = JSON.parse(this.stringJson);
    console.log("JSON object -", this.stringObject.length); 
    
    
    },(error) => {
        console.log("Error From API is", error); 
      
    })
  }
}